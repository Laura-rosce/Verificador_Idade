# Verificador_Idade
Mini programa que calcula a idade e de acordo com ela mostra uma imagem correspondente;
